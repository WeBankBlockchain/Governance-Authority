package com.webank.authmanager.model;

public class FunctionInfo {

    private String contractName;

    private String functionName;

    private String methodSign;

}


